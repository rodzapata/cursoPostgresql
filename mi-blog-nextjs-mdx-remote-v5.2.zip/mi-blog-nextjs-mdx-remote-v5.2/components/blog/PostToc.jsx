export default function PostToc({ toc = [] }) {
  if (!toc.length) return null

  return (
    <aside className="post-toc">
      <div className="toc-card">
        <h3>Contenido</h3>
        <ul>
          {toc.map((item) => (
            <li key={item.id} className={`toc-level-${item.level}`}>
              <a href={`#${item.id}`}>{item.text}</a>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  )
}
