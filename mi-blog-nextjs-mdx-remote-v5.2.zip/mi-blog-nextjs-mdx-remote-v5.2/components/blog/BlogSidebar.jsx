import Link from 'next/link'
import { slugify } from '../../lib/utils'

export default function BlogSidebar({ posts = [], categories = [] }) {
  return (
    <aside className="blog-sidebar">
      <div className="sidebar-card">
        <h2>Navegación</h2>
        <nav className="sidebar-nav">
          <Link href="/">Inicio</Link>
          <Link href="/blog">Todos los artículos</Link>
        </nav>
      </div>

      <div className="sidebar-card">
        <h2>Categorías</h2>
        <ul className="sidebar-list">
          {categories.map((category) => (
            <li key={category}>
              {category === 'Todas' ? (
                <Link href="/blog">{category}</Link>
              ) : (
                <Link href={`/blog/categoria/${slugify(category)}`}>{category}</Link>
              )}
            </li>
          ))}
        </ul>
      </div>

      <div className="sidebar-card">
        <h2>Posts</h2>
        <ul className="sidebar-list">
          {posts.map((post) => (
            <li key={post.slug}>
              <Link href={`/blog/${post.slug}`}>{post.title}</Link>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  )
}
