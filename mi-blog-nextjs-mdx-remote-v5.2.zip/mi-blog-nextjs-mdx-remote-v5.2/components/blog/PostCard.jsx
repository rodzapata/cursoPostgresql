import Link from 'next/link'
import { formatDate, slugify } from '../../lib/utils'

export default function PostCard({ post }) {
  return (
    <article className="post-card">
      <div className="post-card-meta">
        <span>{formatDate(post.date)}</span>
        <span>{post.readingTime}</span>
      </div>

      <h2>
        <Link href={`/blog/${post.slug}`}>{post.title}</Link>
      </h2>

      <p>{post.description}</p>

      <div className="post-card-footer">
        <Link href={`/blog/categoria/${slugify(post.category)}`} className="badge">
          {post.category}
        </Link>
      </div>
    </article>
  )
}
