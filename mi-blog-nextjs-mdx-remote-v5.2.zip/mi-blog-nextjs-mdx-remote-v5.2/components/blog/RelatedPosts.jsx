import Link from 'next/link'

export default function RelatedPosts({ posts = [] }) {
  if (!posts.length) return null

  return (
    <section className="related-posts">
      <h2>Artículos relacionados</h2>
      <div className="related-grid">
        {posts.map((post) => (
          <article key={post.slug} className="related-card">
            <h3>
              <Link href={`/blog/${post.slug}`}>{post.title}</Link>
            </h3>
            <p>{post.description}</p>
          </article>
        ))}
      </div>
    </section>
  )
}
