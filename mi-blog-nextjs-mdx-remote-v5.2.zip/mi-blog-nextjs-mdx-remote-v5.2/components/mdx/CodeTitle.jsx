export default function CodeTitle({ children }) {
  return <div className="code-title">{children}</div>
}
