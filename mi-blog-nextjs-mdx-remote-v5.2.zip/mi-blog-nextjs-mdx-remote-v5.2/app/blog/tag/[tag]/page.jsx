import BlogSidebar from '../../../../components/blog/BlogSidebar'
import PostCard from '../../../../components/blog/PostCard'
import { getAllCategories, getAllPosts, getPostsByTag } from '../../../../lib/posts'

export default async function TagPage({ params }) {
  const { tag } = await params
  const posts = getPostsByTag(tag)
  const allPosts = getAllPosts()
  const categories = getAllCategories()

  return (
    <div className="blog-layout">
      <BlogSidebar posts={allPosts} categories={categories} />
      <main className="content-area">
        <div className="page-header">
          <h1>Etiqueta</h1>
          <p>{tag}</p>
        </div>
        <div className="posts-grid">
          {posts.map((post) => <PostCard key={post.slug} post={post} />)}
        </div>
      </main>
    </div>
  )
}
