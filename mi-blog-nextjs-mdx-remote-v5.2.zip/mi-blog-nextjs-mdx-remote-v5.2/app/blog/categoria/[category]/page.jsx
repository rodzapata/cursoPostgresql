import BlogSidebar from '../../../../components/blog/BlogSidebar'
import PostCard from '../../../../components/blog/PostCard'
import { getAllCategories, getAllPosts, getPostsByCategory } from '../../../../lib/posts'

export default async function CategoryPage({ params }) {
  const { category } = await params
  const posts = getPostsByCategory(category)
  const allPosts = getAllPosts()
  const categories = getAllCategories()

  return (
    <div className="blog-layout">
      <BlogSidebar posts={allPosts} categories={categories} />
      <main className="content-area">
        <div className="page-header">
          <h1>Categoría</h1>
          <p>{category}</p>
        </div>
        <div className="posts-grid">
          {posts.map((post) => <PostCard key={post.slug} post={post} />)}
        </div>
      </main>
    </div>
  )
}
