import BlogSidebar from '../../components/blog/BlogSidebar'
import PostCard from '../../components/blog/PostCard'
import { getAllCategories, getAllPosts } from '../../lib/posts'

export const metadata = {
  title: 'Blog'
}

export default function BlogPage() {
  const posts = getAllPosts()
  const categories = getAllCategories()

  return (
    <div className="blog-layout">
      <BlogSidebar posts={posts} categories={categories} />

      <main className="content-area">
        <div className="page-header">
          <h1>Artículos</h1>
          <p>Explora las publicaciones del blog.</p>
        </div>

        <div className="posts-grid">
          {posts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      </main>
    </div>
  )
}
