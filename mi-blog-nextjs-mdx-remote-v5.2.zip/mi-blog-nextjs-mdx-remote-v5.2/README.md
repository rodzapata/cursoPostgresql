# mi-blog-nextjs-mdx-remote-v5.2

## Ejecutar
```bash
npm install
npm run dev
```

## Qué incluye
- Next.js 15
- MDX con next-mdx-remote
- Frontmatter con gray-matter
- Categorías, tags y posts relacionados
- TOC lateral
- Bloques de código con botón copiar usando lucide-react
